﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace doubleLL
{
    class Program
    {
        static void Main(string[] args)
        {

            doubleLL ob = new doubleLL();
            int ch, ele, pos,oc;

            do
            {
                Console.WriteLine("1 Insert in the beginning");
                Console.WriteLine("2 Insert in the end");
                Console.WriteLine("3 Insert at  a given pos");
                Console.WriteLine("4 delete in the begin");
                Console.WriteLine("5 delete in the end");
                Console.WriteLine("6 delete at a given pos");
                Console.WriteLine("7 Display");
                Console.WriteLine("8 find element");
                Console.WriteLine("9 find element at pos");
                Console.WriteLine("10 Exit");
                ch = int.Parse(Console.ReadLine());

                switch (ch)
                {
                    case 1:
                        Console.WriteLine("Enter the element ");
                        ele = int.Parse(Console.ReadLine());
                        ob.insertbegin(ele);
                        break;
                    case 2:
                        Console.WriteLine("Enter the element ");
                        ele = int.Parse(Console.ReadLine());
                        ob.insertend(ele);
                        break;
                    case 3:
                        Console.WriteLine("Enter the element ");
                        ele = int.Parse(Console.ReadLine());

                        do
                        {
                            Console.WriteLine("Enter position");
                            pos = int.Parse(Console.ReadLine());
                        } while (pos < 1 || pos > ob.count + 1);

                        ob.insertpos(ele, pos);
                        break;
                    case 4:
                        Console.WriteLine("Enter the element ");
                        ele = int.Parse(Console.ReadLine());
                        ob.deletebegin();
                        break;
                    case 5:
                        Console.WriteLine("Enter the element ");
                        ele = int.Parse(Console.ReadLine());
                        ob.deleteend();
                        break;
                    case 6:
                        Console.WriteLine("Enter the element ");
                        ele = int.Parse(Console.ReadLine());

                        do
                        {
                            Console.WriteLine("Enter position");
                            pos = int.Parse(Console.ReadLine());
                        } while (pos < 1 || pos > ob.count + 1);

                        ob.deletepos(pos);
                        break;
                    case 7:
                        ob.display();
                        break;
                    case 8:
                        Console.WriteLine("Enter the element ");
                        ele = int.Parse(Console.ReadLine());
                        ob.find(ele);
                        break;
                    case 10: break;
                    default: Console.WriteLine("invalid choice"); break;
                }
            } while (ch != 8);
        }
    }
}
